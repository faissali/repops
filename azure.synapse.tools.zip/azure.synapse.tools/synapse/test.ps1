# Connexion à Azure
Import-Module -Name .\azure.synapse.tools.psd1 -Verbose    
Connect-AzAccount
Set-AzContext -Subscription "14451a32-9abf-47f3-ab11-e00284963712"

# Export files from source synapse
#$SourceResourceGroupName = 'fbu-synapse-rg'
$SourceSynapseWorkspaceName = "fbusynapse"
#$DestinationResourceGroupName = 'rg-devops'
#$DestinationSynapseWorkspaceName = "fbusynapsecopy"


# Get synapse sql scripts
Export-AzSynapseNotebook -WorkspaceName $SourceSynapseWorkspaceName -OutputFolder "$PSScriptRoot\notebook"

# Get synapse sql scripts
Export-AzSynapseSqlScript -WorkspaceName $SourceSynapseWorkspaceName -OutputFolder "$PSScriptRoot\sqlscript"

# Get synapse sql Pools
#$sqlPools = Get-AzSynapseSqlPool -WorkspaceName $SourceSynapseWorkspaceName

# Get synapse spark pools
#$sparkPools = Get-AzSynapseSparkPool -WorkspaceName $SourceSynapseWorkspaceName

$adminLogin = "faissalitto"
$adminPassword = "Password123!"
$password = ConvertTo-SecureString $adminPassword -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($adminLogin, $password)


# Publish entire Synapse Workspace
$ResourceGroupName = 'devops-rg'
$SynapseWorkspaceName = "fbusynapsecopy"
$Location = "WestEurope"

# get current ip address
$ip = Invoke-RestMethod http://ipinfo.io/json | Select -exp ip

# Publish synapse from artifacts
#Publish-SynapseFromJson -RootFolder $PSScriptRoot -ResourceGroupName "$ResourceGroupName" -SynapseWorkspaceName "$SynapseWorkspaceName" -Location "$Location" -Ip $ip -cred $creds -Method "AzSynapse"

#Publish-SynapseFromDevSynapse -DestinationResourceGroupName "$DestinationResourceGroupName" `
#-DestinationSynapseWorkspaceName "$DestinationSynapseWorkspaceName" `
#-SourceResourceGroupName "$SourceResourceGroupName" `
#-SourceSynapseWorkspaceName "$SourceSynapseWorkspaceName" `
#-Location $Location `
#-cred $creds

