function Import-SynapseSqlObjects {
    [CmdletBinding()]
    param (
        [parameter(Mandatory = $true)] $synapse,
        [parameter(Mandatory = $true)] $All,
        [parameter(Mandatory = $true)] [String] $RootFolder,
        [parameter(Mandatory = $true)] [String] $SubFolder
    )

    Write-Verbose "Analyzing $SubFolder dependencies..."

    $folder = Join-Path $RootFolder "$SubFolder"
    if (-Not (Test-Path -Path "$folder" -ErrorAction Ignore))
    {
        Write-Verbose "Folder: '$folder' does not exist. No objects to be imported."
        return
    }

    Write-Verbose "Folder: $folder"
    Get-ChildItem "$folder" -Filter "*.sql" | Where-Object { !$_.Name.StartsWith('~') } |
    Foreach-Object {
        Write-Verbose "- $($_.Name)"
        $o = New-Object -TypeName SynapseObject 
        $o.Name = $_.BaseName
        $o.Type = $SubFolder
        $o.FileName = $_.FullName
        $o.Synapse = $Synapse
        $o.Body = "{}" | ConvertFrom-Json
        $All.Add($o)
    }
}