class ConfigLine {
    [string] $type = ""
    [string] $name = ""
    [string] $path = ""
    [string] $value = ""
}

