<#
.SYNOPSIS
Publishes all Synapse Workspace objects from a synapse resource into target Synapse Workspace service.

.DESCRIPTION
Publishes all Synapse Workspace objects from a synapse resource into target Synapse Workspace service.
Creates a Synapse Workspace with the specified resource group name and location, if that doesn't exist.
Takes care of creating Synapse Workspace, appropriate order of deployment, deleting objects not in the source anymore, replacing properties environment-related based on CSV config file, and more.

.PARAMETER DestinationResourceGroupName
Resource Group Name of target instance of Synapse Workspace

.PARAMETER DestinationSynapseWorkspaceName
Name of target Synapse Workspace instance

.PARAMETER SourceResourceGroupName
Resource Group Name of source instance of Synapse Workspace

.PARAMETER SourceSynapseWorkspaceName
Name of source Synapse Workspace instance

.PARAMETER Stage
Optional parameter. When defined, process will replace all properties defined in (csv) configuration file.
The parameter can be either full path to csv file (must ends with .csv) or just stage name.
When you provide parameter value 'UAT' the process will try open config file located .\deployment\config-UAT.csv

.PARAMETER Location
Azure Region for target Synapse Workspace. Used only for create new Synapse Workspace instance.

.PARAMETER Method
Optional parameter. Currently this cmdlet contains two method of publishing: AzSynapse, AzResource (default).
AzResource method has been introduced due to bugs in Az.Synapse PS module.
#>
function Publish-SynapseFromDevSynapse {
    [CmdletBinding()]
    param
    (        
        [parameter(Mandatory = $true)] 
        [String] $DestinationSynapseWorkspaceName,

        [parameter(Mandatory = $true)] 
        [String] $DestinationResourceGroupName,
        
        [parameter(Mandatory = $true)] 
        [String] $SourceSynapseWorkspaceName,

        [parameter(Mandatory = $true)] 
        [String] $SourceResourceGroupName,
        
        [parameter(Mandatory = $false)] 
        [String] $Stage = $null,
        
        [parameter(Mandatory = $false)] 
        [String] $Location,

        [parameter(Mandatory = $false)] 
        [ValidateSet('AzSynapse','AzResource')] 
        [String]$Method = 'AzResource',
        
        [System.Management.Automation.PSCredential] $cred
    )

    $m = Get-Module -Name "azure.synapse.tools"
    $verStr = $m.Version.ToString(2) + "." + $m.Version.Build.ToString("000");
    Write-Host "======================================================================================";
    Write-Host "### azure.synapse.tools                                            Version $verStr ###";
    Write-Host "======================================================================================";
    Write-Host "Invoking Publish-SynapseFromJson (https://github.com/SQLPlayer/azure.synapse.tools)";
    Write-Host "with the following parameters:";
    Write-Host "======================================================================================";
    Write-Host "DestinationsResourceGroupName:  $DestinationResourceGroupName";
    Write-Host "DestinationSynapse Workspace:  $DestinationSynapseWorkspaceName";
    Write-Host "SourceResourceGroupName:        $SourceResourceGroupName";
    Write-Host "SourceSynapse Workspace:        $SourceSynapseWorkspaceName";
    Write-Host "Location:           $Location";
    Write-Host "Stage:              $Stage";
    #Write-Host "Options provided:   $($null -ne $Option)";
    Write-Host "Publishing method:  $Method";
    Write-Host "======================================================================================";

    $script:StartTime = Get-Date
    $script:PublishMethod = $Method


    Write-Host "Create Publish options."
    $opt = New-SynapsePublishOption
    
    # Get  synapse from source
    Write-Host "======================================================================================";
    Write-Host "STEP: Reading Synapse Workspace from source..."
    
    $sourceSynapse = Get-AzSynapseWorkspace `
        -ResourceGroupName $SourceResourceGroupName `
        -Name $SourceSynapseWorkspaceName 

    Write-Host "STEP: Verifying whether Synapse workspace exists..."
    $targetSynapse = Get-AzSynapseWorkspace -ResourceGroupName "$DestinationResourceGroupName" -Name "$DestinationSynapseWorkspaceName" -ErrorAction:Ignore
     
    if ($targetSynapse) {
        Write-Host "Synapse Workspace exists."
    } else {
        $msg = "Synapse Workspace instance does not exist."
        if ($opt.CreateNewInstance) {
            Write-Host "$msg"
            Write-Host "Creating a new instance of Synapse Workspace..."
            # params to be reviewed
            $targetSynapse = New-AzSynapseWorkspace -ResourceGroupName "$DestinationResourceGroupName" -Name "$DestinationSynapseWorkspaceName" -Location "$Location" -DefaultDataLakeStorageAccountName "fbutest" -DefaultDataLakeStorageFilesystem  "fbufstest" -SqlAdministratorLoginCredential $cred
            $targetSynapse | Format-List | Out-String
        } else {
            Write-Host "Creation operation skipped as publish option 'CreateNewInstance' = false"
            Write-Error "$msg"
        }
    }

    $synapse = New-Object -TypeName Synapse 
    $synapse.Name = $DestinationSynapseWorkspaceName

    # Get triggers
    $triggers = Get-AzSynapseTrigger -WorkspaceName $SourceSynapseWorkspaceName


    $synapse.Triggers = $triggers
    $synapse.ResourceGroupName = "$DestinationResourceGroupName";
    $synapse.Region = "$Location";
    $synapse.PublishOptions = $opt
    Write-Debug ($synapse | Format-List | Out-String)


    # deploy triggers to destination synapse workspace
    Write-Host "======================================================================================";
    Write-Host "STEP: Deploying triggers to destination synapse workspace..."
    $synapse.Triggers | ForEach-Object {
        $trigger = $_
        Write-Host "Deploying trigger $($trigger.Name)..."
        $trigger | Format-List | Out-String
        #$trigger | Publish-SynapseTrigger -Synapse $synapse -Force
    }

    return $synapse
}
